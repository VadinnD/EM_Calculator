﻿namespace Calc
{
    partial class MatrixInput
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.DialogResult = DialogResult.OK;
            button1.Location = new Point(1, 1);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            // 
            // MatrixInput
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DimGray;
            ClientSize = new Size(484, 461);
            Controls.Add(button1);
            FormBorderStyle = FormBorderStyle.None;
            MinimizeBox = false;
            Name = "MatrixInput";
            Opacity = 0.98D;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MatrixInput";
            ResumeLayout(false);
        }

        #endregion

        public Button button1;
        private Label header;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox dataBox;
        private Siticone.Desktop.UI.WinForms.SiticoneButton resBtn;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox resBox;
    }
}