﻿using Siticone.Desktop.UI.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace Calc
{
    public partial class MatrixMul : Form
    {
        public Point mouseLocation;

        const int MaxN = 10;

        int n1 = 3;
        int m1 = 3;

        int n2 = 3;
        int m2 = 3;

        TextBox[,] MatrText = null;
        double[,] Matr1 = new double[MaxN, MaxN];
        double[,] Matr2 = new double[MaxN, MaxN];
        double[,] Matr3 = new double[MaxN, MaxN];
        bool f1;

        bool f2;

        int dx = 40, dy = 20;

        MatrixInput form2 = null;

        public MatrixMul()
        {
            InitializeComponent();

            new SiticoneShadowForm(this);
        }

        private void topBar_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void topBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void MatrixSum_Load(object sender, EventArgs e)
        {
            errorLabel.Text = "";
            textBox1.Text = "";
            f1 = f2 = false;
            label2.Text = "false";
            label3.Text = "false";

            int i, j;
            form2 = new MatrixInput();

            MatrText = new TextBox[MaxN, MaxN];

            for (i = 0; i < MaxN; i++)
                for (j = 0; j < MaxN; j++)
                {
                    MatrText[i, j] = new TextBox();

                    MatrText[i, j].Text = "0";

                    MatrText[i, j].Location = new System.Drawing.Point(10 + i * dx, 10 + j * dy);

                    MatrText[i, j].Size = new System.Drawing.Size(dx, dy);

                    MatrText[i, j].Visible = false;
                    form2.Controls.Add(MatrText[i, j]);
                }
        }
        private void Clear_MatrText()
        {
            for (int i = 0; i < n1; i++)
                for (int j = 0; j < m1; j++)
                    MatrText[i, j].Text = "0";

            for (int i = 0; i < n1; i++)
                for (int j = 0; j < m1; j++)
                {
                    MatrText[i, j].TabIndex = i * n1 + j * m1 + 1;

                    MatrText[i, j].Visible = false;
                }

            for (int i = 0; i < n2; i++)
                for (int j = 0; j < m2; j++)
                    MatrText[i, j].Text = "0";

            for (int i = 0; i < n2; i++)
                for (int j = 0; j < m2; j++)
                {
                    MatrText[i, j].TabIndex = i * n2 + j * m2 + 1;

                    MatrText[i, j].Visible = false;
                }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            errorLabel.Text = "";

            bool n1Number = int.TryParse(textBox1.Text, out n1);
            if (textBox1.Text == "" || !n1Number)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            bool m1Number = int.TryParse(textBox2.Text, out m1);
            if (textBox2.Text == "" || !m1Number)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            if (n1Number && m1Number)
            {

                Clear_MatrText();

                for (int i = 0; i < n1; i++)
                    for (int j = 0; j < m1; j++)
                    {
                        MatrText[i, j].TabIndex = i * n1 + j * m1 + 1;

                        MatrText[i, j].Visible = true;
                    }

                form2.Width = 10 + n1 * dx + 20;
                form2.Height = 10 + m1 * dy + form2.button1.Height + 50;

                form2.button1.Left = 10;
                form2.button1.Top = 10 + m1 * dy + 10;
                form2.button1.Width = form2.Width - 30;

                if (form2.ShowDialog() == DialogResult.OK)
                {
                    for (int i = 0; i < n1; i++)
                        for (int j = 0; j < m1; j++)
                            if (MatrText[i, j].Text != "")
                                Matr1[i, j] = Double.Parse(MatrText[i, j].Text);
                            else
                                Matr1[i, j] = 0;

                    f1 = true;
                    label2.Text = "true";
                    errorLabel.Text = "";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            errorLabel.Text = "";

            bool n2Number = int.TryParse(textBox3.Text, out n2);
            if (textBox1.Text == "" || !n2Number)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            bool m2Number = int.TryParse(textBox4.Text, out m2);
            if (textBox2.Text == "" || !m2Number)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            if (n2Number && m2Number)
            {

                Clear_MatrText();

                for (int i = 0; i < n2; i++)
                    for (int j = 0; j < m2; j++)
                    {
                        MatrText[i, j].TabIndex = i * n2 + j * m2 + 1;

                        MatrText[i, j].Visible = true;
                    }

                form2.Width = 10 + n2 * dx + 20;
                form2.Height = 10 + m2 * dy + form2.button1.Height + 50;

                form2.button1.Left = 10;
                form2.button1.Top = 10 + m2 * dy + 10;
                form2.button1.Width = form2.Width - 30;

                if (form2.ShowDialog() == DialogResult.OK)
                {
                    for (int i = 0; i < n2; i++)
                        for (int j = 0; j < m2; j++)
                            if (MatrText[i, j].Text != "")
                                Matr2[i, j] = Double.Parse(MatrText[i, j].Text);
                            else
                                Matr2[i, j] = 0;

                    f2 = true;
                    label3.Text = "true";
                    errorLabel.Text = "";
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            errorLabel.Text = "";
            if (!((f1 == true) && (f2 == true))) return;

            if (n1 != m2)
            {
                errorLabel.Text = "Количество столбцов в первой матрице должно быть равно количеству строк во второй";
                return;
            }

            for (int i = 0; i < m1; i++)
                for (int j = 0; j < n2; j++)
                {
                    Matr3[j, i] = 0;
                    for (int k = 0; k < m2; k++)
                        Matr3[j, i] = Matr3[j, i] + Matr1[k, i] * Matr2[j, k];
                }

            Clear_MatrText();

            for (int i = 0; i < n2; i++)
                for (int j = 0; j < m1; j++)
                {
                    MatrText[i, j].TabIndex = i * n2 + j * m1 + 1;

                    MatrText[i, j].Visible = true;
                }

            form2.Width = 10 + n2 * dx + 20;
            form2.Height = 10 + m1 * dy + form2.button1.Height + 50;

            form2.button1.Left = 10;
            form2.button1.Top = 10 + m1 * dy + 10;
            form2.button1.Width = form2.Width - 30;

            for (int i = 0; i < n2; i++)
                for (int j = 0; j < m1; j++)
                {
                    MatrText[i, j].TabIndex = i * n2 + j * m1 + 1;

                    MatrText[i, j].Text = Matr3[i, j].ToString();
                }

            form2.ShowDialog();
        }
    }
}
