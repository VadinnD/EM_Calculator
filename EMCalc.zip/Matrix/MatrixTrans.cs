﻿using Siticone.Desktop.UI.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace Calc
{
    public partial class MatrixTrans : Form
    {
        public Point mouseLocation;

        const int MaxN = 10;
        int n = 3;
        int m = 3;

        TextBox[,] MatrText = null;
        double[,] Matr1 = new double[MaxN, MaxN];
        double[,] Matr3 = new double[MaxN, MaxN];
        bool f1;

        int dx = 40, dy = 20;

        MatrixInput form2 = null;

        public MatrixTrans()
        {
            InitializeComponent();

            new SiticoneShadowForm(this);
        }

        private void topBar_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void topBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void Clear_MatrText()
        {
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    MatrText[i, j].Text = "0";

            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                {
                    MatrText[i, j].TabIndex = i * n + j * m + 1;

                    MatrText[i, j].Visible = false;
                }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            errorLabel.Text = "";

            bool nNumber = int.TryParse(textBox1.Text, out n);
            if (textBox1.Text == "" || !nNumber)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            bool mNumber = int.TryParse(textBox2.Text, out m);
            if (textBox2.Text == "" || !mNumber)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            if (nNumber && mNumber)
            {

                Clear_MatrText();

                for (int i = 0; i < n; i++)
                    for (int j = 0; j < m; j++)
                    {
                        MatrText[i, j].TabIndex = i * n + j * m + 1;

                        MatrText[i, j].Visible = true;
                    }

                form2.Width = 10 + n * dx + 20;
                form2.Height = 10 + m * dy + form2.button1.Height + 50;

                form2.button1.Left = 10;
                form2.button1.Top = 10 + m * dy + 10;
                form2.button1.Width = form2.Width - 30;

                if (form2.ShowDialog() == DialogResult.OK)
                {
                    for (int i = 0; i < n; i++)
                        for (int j = 0; j < m; j++)
                            if (MatrText[i, j].Text != "")
                                Matr1[i, j] = Double.Parse(MatrText[i, j].Text);
                            else
                                Matr1[i, j] = 0;

                    f1 = true;
                    label2.Text = "true";
                    errorLabel.Text = "";
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!(f1 == true)) return;

            int tn = m;
            int tm = n;

            for (int i = 0; i < tn; i++)
                for (int j = 0; j < tm; j++)
                {
                    Matr3[i, j] = Matr1[j, i];
                }

            Clear_MatrText();

            form2.Width = 10 + m * dx + 20;
            form2.Height = 10 + n * dy + form2.button1.Height + 50;

            form2.button1.Left = 10;
            form2.button1.Top = 10 + n * dy + 10;
            form2.button1.Width = form2.Width - 30;

            for (int i = 0; i < tn; i++)
                for (int j = 0; j < tm; j++)
                {
                    MatrText[i, j].TabIndex = i * tn + j * tm + 1;

                    MatrText[i, j].Visible = true;
                }

            for (int i = 0; i < tn; i++)
                for (int j = 0; j < tm; j++)
                {
                    MatrText[i, j].TabIndex = i * tn + j * tm + 1;

                    MatrText[i, j].Text = Matr3[i, j].ToString();
                }

            form2.ShowDialog();
        }

        private void MatrixTrans_Load(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            f1 = false;
            label2.Text = "false";

            int i, j;
            form2 = new MatrixInput();

            MatrText = new TextBox[MaxN, MaxN];

            for (i = 0; i < MaxN; i++)
                for (j = 0; j < MaxN; j++)
                {
                    MatrText[i, j] = new TextBox();

                    MatrText[i, j].Text = "0";

                    MatrText[i, j].Location = new System.Drawing.Point(10 + i * dx, 10 + j * dy);

                    MatrText[i, j].Size = new System.Drawing.Size(dx, dy);

                    MatrText[i, j].Visible = false;
                    form2.Controls.Add(MatrText[i, j]);
                }
        }
    }
}
