﻿using Siticone.Desktop.UI.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace Calc
{
    public partial class MatrixDet : Form
    {
        public Point mouseLocation;

        const int MaxN = 10;
        int n = 3;

        TextBox[,] MatrText = null;
        double[,] Matr1 = new double[MaxN, MaxN];
        bool f1;

        int dx = 40, dy = 20;

        MatrixInput form2 = null;

        public MatrixDet()
        {
            InitializeComponent();

            new SiticoneShadowForm(this);
        }

        private void topBar_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void topBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void Clear_MatrText()
        {
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    MatrText[i, j].Text = "0";

            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    MatrText[i, j].TabIndex = i * n + j * n + 1;

                    MatrText[i, j].Visible = false;
                }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            errorLabel.Text = "";

            bool nNumber = int.TryParse(textBox1.Text, out n);
            if (textBox1.Text == "" || !nNumber)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            if (nNumber)
            {

                Clear_MatrText();

                for (int i = 0; i < n; i++)
                    for (int j = 0; j < n; j++)
                    {
                        MatrText[i, j].TabIndex = i * n + j * n + 1;

                        MatrText[i, j].Visible = true;
                    }

                form2.Width = 10 + n * dx + 20;
                form2.Height = 10 + n * dy + form2.button1.Height + 50;

                form2.button1.Left = 10;
                form2.button1.Top = 10 + n * dy + 10;
                form2.button1.Width = form2.Width - 30;

                if (form2.ShowDialog() == DialogResult.OK)
                {
                    for (int i = 0; i < n; i++)
                        for (int j = 0; j < n; j++)
                            if (MatrText[i, j].Text != "")
                                Matr1[i, j] = Double.Parse(MatrText[i, j].Text);
                            else
                                Matr1[i, j] = 0;

                    f1 = true;
                    label2.Text = "true";
                    errorLabel.Text = "";
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!(f1 == true)) return;

            double? res = 0;

            if (n == 1) res = Matr1[0, 0];
            if (n == 2) res = Matr1[0, 0] * Matr1[1, 1] - Matr1[0, 1] * Matr1[1, 0];
            if (n != 1 && n != 2)
            {
                double[,] AlgebraicComplement = new double[n - 1, n - 1];

                for (int m = 0; m < n; m++)
                {
                    int a = 0;

                    for (int k = 1; k < n; k++)
                    {
                        int b = 0;

                        for (int l = 0; l < n; l++)
                        {
                            if (l != m)
                            {
                                AlgebraicComplement[a, b] = Matr1[k, l];
                                b++;
                            }
                        }
                        a++;
                    }
                    res += Math.Pow(-1, m) * Matr1[0, m] * MatrixDeterminant(AlgebraicComplement);
                }

            }

            resLabel.Text = res.ToString();

        }

        private void MatrixDet_Load(object sender, EventArgs e)
        {
            errorLabel.Text = "";
            resLabel.Text = "";
            textBox1.Text = "";
            f1 = false;
            label2.Text = "false";

            int i, j;
            form2 = new MatrixInput();

            MatrText = new TextBox[MaxN, MaxN];

            for (i = 0; i < MaxN; i++)
                for (j = 0; j < MaxN; j++)
                {
                    MatrText[i, j] = new TextBox();

                    MatrText[i, j].Text = "0";

                    MatrText[i, j].Location = new System.Drawing.Point(10 + i * dx, 10 + j * dy);

                    MatrText[i, j].Size = new System.Drawing.Size(dx, dy);

                    MatrText[i, j].Visible = false;
                    form2.Controls.Add(MatrText[i, j]);
                }
        }
        private double MatrixDeterminant(double[,] Matrix)
        {
            int M = Matrix.GetLength(0);
            int N = Matrix.GetLength(1);

            if (M == N)
            {
                double res = 0;

                if (M == 1)
                {
                    res = Matrix[0, 0];
                }
                else if (M == 2)
                {
                    res = Matrix[0, 0] * Matrix[1, 1] - Matrix[0, 1] * Matrix[1, 0];
                }
                else
                {
                    double[,] AlgebraicComplement = new double[M - 1, M - 1];

                    for (int m = 0; m < M; m++)
                    {
                        int a = 0;

                        for (int k = 1; k < M; k++)
                        {
                            int b = 0;

                            for (int l = 0; l < M; l++)
                            {
                                if (l != m)
                                {
                                    AlgebraicComplement[a, b] = Matrix[k, l];
                                    b++;
                                }
                            }
                            a++;
                        }
                        res += Math.Pow(-1, m) * Matrix[0, m] * MatrixDeterminant(AlgebraicComplement);
                    }

                }

                return res;
            }
            else
            {
                throw new Exception("Matrix must be square.");
            }
        }
    }
}
