﻿namespace Calc
{
    partial class MatrixSub
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            siticoneControlBox3 = new Siticone.Desktop.UI.WinForms.SiticoneControlBox();
            siticoneControlBox2 = new Siticone.Desktop.UI.WinForms.SiticoneControlBox();
            siticoneControlBox1 = new Siticone.Desktop.UI.WinForms.SiticoneControlBox();
            topBar = new Panel();
            header = new Label();
            textBox1 = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            button3 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            button1 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            button2 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            label4 = new Label();
            textBox2 = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            errorLabel = new Label();
            topBar.SuspendLayout();
            SuspendLayout();
            // 
            // siticoneControlBox3
            // 
            siticoneControlBox3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            siticoneControlBox3.ControlBoxStyle = Siticone.Desktop.UI.WinForms.Enums.ControlBoxStyle.Custom;
            siticoneControlBox3.ControlBoxType = Siticone.Desktop.UI.WinForms.Enums.ControlBoxType.MaximizeBox;
            siticoneControlBox3.FillColor = Color.FromArgb(25, 40, 65);
            siticoneControlBox3.HoverState.FillColor = Color.FromArgb(28, 46, 74);
            siticoneControlBox3.IconColor = Color.Silver;
            siticoneControlBox3.Location = new Point(395, 0);
            siticoneControlBox3.Name = "siticoneControlBox3";
            siticoneControlBox3.Size = new Size(45, 27);
            siticoneControlBox3.TabIndex = 4;
            // 
            // siticoneControlBox2
            // 
            siticoneControlBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            siticoneControlBox2.ControlBoxStyle = Siticone.Desktop.UI.WinForms.Enums.ControlBoxStyle.Custom;
            siticoneControlBox2.ControlBoxType = Siticone.Desktop.UI.WinForms.Enums.ControlBoxType.MinimizeBox;
            siticoneControlBox2.FillColor = Color.FromArgb(25, 40, 65);
            siticoneControlBox2.HoverState.FillColor = Color.FromArgb(28, 46, 74);
            siticoneControlBox2.IconColor = Color.Silver;
            siticoneControlBox2.Location = new Point(350, 0);
            siticoneControlBox2.Name = "siticoneControlBox2";
            siticoneControlBox2.Size = new Size(45, 27);
            siticoneControlBox2.TabIndex = 5;
            // 
            // siticoneControlBox1
            // 
            siticoneControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            siticoneControlBox1.BackColor = Color.Transparent;
            siticoneControlBox1.ControlBoxStyle = Siticone.Desktop.UI.WinForms.Enums.ControlBoxStyle.Custom;
            siticoneControlBox1.FillColor = Color.FromArgb(25, 40, 65);
            siticoneControlBox1.HoverState.FillColor = Color.FromArgb(128, 60, 60);
            siticoneControlBox1.IconColor = Color.Silver;
            siticoneControlBox1.Location = new Point(440, 0);
            siticoneControlBox1.Name = "siticoneControlBox1";
            siticoneControlBox1.Size = new Size(45, 27);
            siticoneControlBox1.TabIndex = 3;
            // 
            // topBar
            // 
            topBar.BackColor = Color.Transparent;
            topBar.Controls.Add(siticoneControlBox3);
            topBar.Controls.Add(siticoneControlBox2);
            topBar.Controls.Add(siticoneControlBox1);
            topBar.Dock = DockStyle.Top;
            topBar.Location = new Point(0, 0);
            topBar.Name = "topBar";
            topBar.Size = new Size(484, 25);
            topBar.TabIndex = 6;
            topBar.MouseDown += topBar_MouseDown;
            topBar.MouseMove += topBar_MouseMove;
            // 
            // header
            // 
            header.AutoSize = true;
            header.Font = new Font("Bahnschrift", 20F, FontStyle.Regular, GraphicsUnit.Point);
            header.ForeColor = Color.Silver;
            header.Location = new Point(117, 46);
            header.Name = "header";
            header.Size = new Size(251, 33);
            header.TabIndex = 7;
            header.Text = "Вычитание матриц";
            // 
            // textBox1
            // 
            textBox1.BorderColor = Color.FromArgb(35, 57, 93);
            textBox1.BorderRadius = 4;
            textBox1.BorderThickness = 2;
            textBox1.DefaultText = "";
            textBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            textBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            textBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            textBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            textBox1.FillColor = Color.FromArgb(25, 40, 65);
            textBox1.FocusedState.BorderColor = Color.White;
            textBox1.FocusedState.FillColor = Color.White;
            textBox1.FocusedState.ForeColor = Color.Black;
            textBox1.FocusedState.PlaceholderForeColor = Color.Black;
            textBox1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.ForeColor = Color.Silver;
            textBox1.HoverState.BorderColor = Color.FromArgb(35, 57, 93);
            textBox1.HoverState.FillColor = Color.FromArgb(35, 57, 93);
            textBox1.HoverState.ForeColor = Color.White;
            textBox1.HoverState.PlaceholderForeColor = Color.White;
            textBox1.IconLeftOffset = new Point(10, 0);
            textBox1.Location = new Point(186, 92);
            textBox1.Name = "textBox1";
            textBox1.PasswordChar = '\0';
            textBox1.PlaceholderForeColor = Color.Silver;
            textBox1.PlaceholderText = "введите данные";
            textBox1.SelectedText = "";
            textBox1.Size = new Size(219, 35);
            textBox1.TabIndex = 8;
            textBox1.TextOffset = new Point(5, 0);
            // 
            // button3
            // 
            button3.Animated = true;
            button3.Cursor = Cursors.Hand;
            button3.DisabledState.BorderColor = Color.DarkGray;
            button3.DisabledState.CustomBorderColor = Color.DarkGray;
            button3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            button3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            button3.FillColor = Color.FromArgb(25, 40, 65);
            button3.Font = new Font("Bahnschrift", 15F, FontStyle.Regular, GraphicsUnit.Point);
            button3.ForeColor = Color.LightGray;
            button3.HoverState.FillColor = Color.FromArgb(35, 57, 93);
            button3.HoverState.ForeColor = Color.Cyan;
            button3.Location = new Point(92, 280);
            button3.Name = "button3";
            button3.PressedColor = Color.Cyan;
            button3.Size = new Size(300, 55);
            button3.TabIndex = 9;
            button3.Text = "Получить результат";
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.Animated = true;
            button1.Cursor = Cursors.Hand;
            button1.DisabledState.BorderColor = Color.DarkGray;
            button1.DisabledState.CustomBorderColor = Color.DarkGray;
            button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            button1.FillColor = Color.FromArgb(25, 40, 65);
            button1.Font = new Font("Bahnschrift", 15F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.LightGray;
            button1.HoverState.FillColor = Color.FromArgb(35, 57, 93);
            button1.HoverState.ForeColor = Color.Cyan;
            button1.Location = new Point(80, 183);
            button1.Name = "button1";
            button1.PressedColor = Color.Cyan;
            button1.Size = new Size(241, 35);
            button1.TabIndex = 12;
            button1.Text = "Ввод первой матрицы";
            button1.TextAlign = HorizontalAlignment.Left;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Animated = true;
            button2.Cursor = Cursors.Hand;
            button2.DisabledState.BorderColor = Color.DarkGray;
            button2.DisabledState.CustomBorderColor = Color.DarkGray;
            button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            button2.FillColor = Color.FromArgb(25, 40, 65);
            button2.Font = new Font("Bahnschrift", 15F, FontStyle.Regular, GraphicsUnit.Point);
            button2.ForeColor = Color.LightGray;
            button2.HoverState.FillColor = Color.FromArgb(35, 57, 93);
            button2.HoverState.ForeColor = Color.Cyan;
            button2.Location = new Point(80, 232);
            button2.Name = "button2";
            button2.PressedColor = Color.Cyan;
            button2.Size = new Size(241, 35);
            button2.TabIndex = 13;
            button2.Text = "Ввод второй матрицы";
            button2.TextAlign = HorizontalAlignment.Left;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bahnschrift", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.Silver;
            label2.Location = new Point(338, 190);
            label2.Name = "label2";
            label2.Size = new Size(65, 24);
            label2.TabIndex = 14;
            label2.Text = "label2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bahnschrift", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.Silver;
            label3.Location = new Point(338, 239);
            label3.Name = "label3";
            label3.Size = new Size(66, 24);
            label3.TabIndex = 15;
            label3.Text = "label3";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Bahnschrift", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Silver;
            label5.Location = new Point(79, 135);
            label5.Name = "label5";
            label5.Size = new Size(101, 33);
            label5.TabIndex = 24;
            label5.Text = "N стр =";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bahnschrift", 20F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.Silver;
            label4.Location = new Point(79, 92);
            label4.Name = "label4";
            label4.Size = new Size(101, 33);
            label4.TabIndex = 23;
            label4.Text = "N стб =";
            // 
            // textBox2
            // 
            textBox2.BorderColor = Color.FromArgb(35, 57, 93);
            textBox2.BorderRadius = 4;
            textBox2.BorderThickness = 2;
            textBox2.DefaultText = "";
            textBox2.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            textBox2.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            textBox2.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            textBox2.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            textBox2.FillColor = Color.FromArgb(25, 40, 65);
            textBox2.FocusedState.BorderColor = Color.White;
            textBox2.FocusedState.FillColor = Color.White;
            textBox2.FocusedState.ForeColor = Color.Black;
            textBox2.FocusedState.PlaceholderForeColor = Color.Black;
            textBox2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.ForeColor = Color.Silver;
            textBox2.HoverState.BorderColor = Color.FromArgb(35, 57, 93);
            textBox2.HoverState.FillColor = Color.FromArgb(35, 57, 93);
            textBox2.HoverState.ForeColor = Color.White;
            textBox2.HoverState.PlaceholderForeColor = Color.White;
            textBox2.IconLeftOffset = new Point(10, 0);
            textBox2.Location = new Point(186, 135);
            textBox2.Name = "textBox2";
            textBox2.PasswordChar = '\0';
            textBox2.PlaceholderForeColor = Color.Silver;
            textBox2.PlaceholderText = "введите данные";
            textBox2.SelectedText = "";
            textBox2.Size = new Size(219, 35);
            textBox2.TabIndex = 25;
            textBox2.TextOffset = new Point(5, 0);
            // 
            // errorLabel
            // 
            errorLabel.Font = new Font("Bahnschrift", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            errorLabel.ForeColor = Color.RosyBrown;
            errorLabel.Location = new Point(0, 340);
            errorLabel.Name = "errorLabel";
            errorLabel.Size = new Size(484, 57);
            errorLabel.TabIndex = 27;
            errorLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // MatrixSub
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(25, 40, 65);
            ClientSize = new Size(484, 461);
            Controls.Add(errorLabel);
            Controls.Add(textBox2);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(button3);
            Controls.Add(textBox1);
            Controls.Add(header);
            Controls.Add(topBar);
            FormBorderStyle = FormBorderStyle.None;
            Name = "MatrixSub";
            Opacity = 0.98D;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MatrixSub";
            Load += MatrixSub_Load;
            topBar.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Siticone.Desktop.UI.WinForms.SiticoneControlBox siticoneControlBox3;
        private Siticone.Desktop.UI.WinForms.SiticoneControlBox siticoneControlBox2;
        private Siticone.Desktop.UI.WinForms.SiticoneControlBox siticoneControlBox1;
        private Panel topBar;
        private Label header;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox textBox1;
        private Siticone.Desktop.UI.WinForms.SiticoneButton button3;
        private Siticone.Desktop.UI.WinForms.SiticoneButton button1;
        private Siticone.Desktop.UI.WinForms.SiticoneButton button2;
        private Label label2;
        private Label label3;
        private Label label5;
        private Label label4;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox textBox2;
        private Label errorLabel;
    }
}