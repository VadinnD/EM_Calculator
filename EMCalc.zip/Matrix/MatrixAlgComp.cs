﻿using Siticone.Desktop.UI.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace Calc
{
    public partial class MatrixAlgComp : Form
    {
        public Point mouseLocation;

        const int MaxN = 10;
        int n = 3;
        int N = 0;
        int M = 0;

        TextBox[,] MatrText = null;
        double[,] Matr1 = new double[MaxN, MaxN];
        double[,] Matr3 = new double[MaxN, MaxN];
        bool f1;

        int dx = 40, dy = 20;

        MatrixInput form2 = null;

        public MatrixAlgComp()
        {
            InitializeComponent();

            new SiticoneShadowForm(this);
        }

        private void topBar_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void topBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void Clear_MatrText()
        {
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    MatrText[i, j].Text = "0";

            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    MatrText[i, j].TabIndex = i * n + j * n + 1;

                    MatrText[i, j].Visible = false;
                }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            errorLabel.Text = "";

            bool nNumber = int.TryParse(textBox1.Text, out n);
            if (textBox1.Text == "" || !nNumber)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            if (nNumber)
            {

                Clear_MatrText();

                for (int i = 0; i < n; i++)
                    for (int j = 0; j < n; j++)
                    {
                        MatrText[i, j].TabIndex = i * n + j * n + 1;

                        MatrText[i, j].Visible = true;
                    }

                form2.Width = 10 + n * dx + 20;
                form2.Height = 10 + n * dy + form2.button1.Height + 50;

                form2.button1.Left = 10;
                form2.button1.Top = 10 + n * dy + 10;
                form2.button1.Width = form2.Width - 30;

                if (form2.ShowDialog() == DialogResult.OK)
                {
                    for (int i = 0; i < n; i++)
                        for (int j = 0; j < n; j++)
                            if (MatrText[i, j].Text != "")
                                Matr1[i, j] = Double.Parse(MatrText[i, j].Text);
                            else
                                Matr1[i, j] = 0;

                    f1 = true;
                    label2.Text = "true";
                    errorLabel.Text = "";
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool n2Number = int.TryParse(textBox2.Text, out N);
            if (textBox2.Text == "" || !n2Number)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            bool n3Number = int.TryParse(textBox3.Text, out M);
            if (textBox3.Text == "" || !n3Number)
            {
                errorLabel.Text = "Введите корректные данные";
            }

            double? res = 0;

            if (n2Number && n3Number)
            {
                res = AlgebraicComplement(Matr1, M, N);
            }

            resLabel.Text = res.ToString();
        }

        private void MatrixAlgComp_Load(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox3.Text = "";
            f1 = false;
            label2.Text = "false";

            int i, j;
            form2 = new MatrixInput();

            MatrText = new TextBox[MaxN, MaxN];

            for (i = 0; i < MaxN; i++)
                for (j = 0; j < MaxN; j++)
                {
                    MatrText[i, j] = new TextBox();

                    MatrText[i, j].Text = "0";

                    MatrText[i, j].Location = new System.Drawing.Point(10 + i * dx, 10 + j * dy);

                    MatrText[i, j].Size = new System.Drawing.Size(dx, dy);

                    MatrText[i, j].Visible = false;
                    form2.Controls.Add(MatrText[i, j]);
                }
        }
        public double? AlgebraicComplement(double[,] matrix, int row, int column)
        {

            int rowsAmount = n;
            int columnsAmount = n;
            double[,] temporary = new double[rowsAmount - 1, columnsAmount - 1];
            try
            {
                for (int i = 0; i < rowsAmount; i++)
                {
                    for (int j = 0; j < columnsAmount; j++)
                    {
                        if (i != row && j != column)
                        {
                            temporary[i < row ? i : i - 1, j < column ? j : j - 1] = matrix[i, j];
                        }
                    }
                }
                return Determinant(temporary) * Math.Pow(-1, row + column);
            }
            catch
            {
                Console.WriteLine("Введите корректные данные");
                return null;
            }
        }
        public double? Determinant(double[,] matrix)
        {
            try
            {
                double rows = n;
                double columns = n;
                if (rows != columns)
                {
                    return null;
                }
                if (rows == 1)
                {
                    return matrix[0, 0];
                }
                if (rows == 2)
                {
                    return matrix[0, 0] * matrix[1, 1] - matrix[0, 1] * matrix[1, 0];
                }
                else
                {
                    double? det = 0;
                    for (int element = 0; element < rows; element++)
                    {
                        det += matrix[0, element] * AlgebraicComplement(matrix, 0, element);
                    }
                    return det;
                }
            }
            catch
            {
                Console.WriteLine("Введите корректные данные");
                return null;
            }
        }
    }
}
