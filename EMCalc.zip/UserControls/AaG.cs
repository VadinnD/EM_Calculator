﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calc.UserControls
{
    public partial class AaG : UserControl
    {
        public AaG()
        {
            InitializeComponent();
            backBtn.Hide();
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            matrixPanel.BringToFront();
            backBtn.BringToFront();
            backBtn.Show();
        }

        private void back_Click(object sender, EventArgs e)
        {
            backBtn.Hide();
            startingPanel.BringToFront();
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            vectorPanel.BringToFront();
            backBtn.BringToFront();
            backBtn.Show();
        }

        private void matrixBtn1_Click(object sender, EventArgs e)
        {
            MatrixMul calcForm = new MatrixMul();
            calcForm.Show();
        }

        private void matrixBtn2_Click(object sender, EventArgs e)
        {
            MatrixSum calcForm = new MatrixSum();
            calcForm.Show();
        }

        private void matrixBtn3_Click(object sender, EventArgs e)
        {
            MatrixSub calcForm = new MatrixSub();
            calcForm.Show();
        }

        private void matrixBtn4_Click(object sender, EventArgs e)
        {
            MatrixTrans calcForm = new MatrixTrans();
            calcForm.Show();
        }

        private void matrixBtn5_Click(object sender, EventArgs e)
        {
            MatrixAlgComp calcForm = new MatrixAlgComp();
            calcForm.Show();
        }

        private void matrixBtn6_Click(object sender, EventArgs e)
        {
            MatrixDet calcForm = new MatrixDet();
            calcForm.Show();
        }
    }
}
