﻿using Siticone.Desktop.UI.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calc.UserControls
{
    public partial class Search : UserControl
    {

        private readonly IEnumerable<SiticoneButton> SearchButtons;

        public Search()
        {
            InitializeComponent();

            SearchButtons = SearchPanel.Controls.OfType<SiticoneButton>();

            SearchBox.TextChanged += SearchBox_TextChanged;
        }

        private void SearchBox_TextChanged(object sender, EventArgs e)
        {
            foreach (SiticoneButton button in SearchButtons)
            {
                if (button.Text.ToLower().Contains(SearchBox.Text.ToLower()))
                {
                    button.Show();
                }
                else
                {
                    button.Hide();
                    continue;
                }
            }
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            MatrixMul calcForm = new MatrixMul();
            calcForm.Show();
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            MatrixSum calcForm = new MatrixSum();
            calcForm.Show();
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            MatrixSub calcForm = new MatrixSub();
            calcForm.Show();
        }

        private void siticoneButton4_Click(object sender, EventArgs e)
        {
            MatrixTrans calcForm = new MatrixTrans();
            calcForm.Show();
        }

        private void siticoneButton5_Click(object sender, EventArgs e)
        {
            MatrixAlgComp calcForm = new MatrixAlgComp();
            calcForm.Show();
        }

        private void siticoneButton6_Click(object sender, EventArgs e)
        {
            MatrixDet calcForm = new MatrixDet();
            calcForm.Show();
        }
    }
}
